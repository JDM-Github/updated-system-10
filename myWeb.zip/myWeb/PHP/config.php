<?php

$conn = mysqli_connect('localhost','root','','lecheria_db');

?>