<!-- Start of PHP Config -->
<?php


?>

<!-- End of PHP Config -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page | Admin</title>

    <!-- CSS FILE LINK -->
    <link rel="stylesheet" href="/myWeb/CSS/style.css">

</head>
<body>
    <div class="container">
        <div class="content">
        <h3> Hi, <span>Admin</span></h3>
        <h1>WELCOME</h1>
        <p>This is an admin page</p>
        <a href="dashboard.php" class="btn">Dashboard</a>
        <a href="viewapplication.php" class="btn">View Applications</a>
        <a href="recommendation.php"class="btn">Recommendations</a>
        </div>
    </div>
        <div class="account_menu">
            <a href="login_form.php" class="btn">Log In</a>
            <a href="register_form.php" class="btn">Register</a>
            <a href="logout.php" class="btn">Log Out</a>
        </div>


</body>
</html>